package com.example.emo;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private EmoView emo;

    private final String[] phrases = {
            "سلام! من ایمو هستم.",
            "وای، چقدر خوشحالم!",
            "اوه! چه خبر شده؟",
            "خوابم میاد..."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        emo = new EmoView(this);
        setContentView(emo);
        tts = new TextToSpeech(this, this);

        emo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int mood = emo.nextMood();
                if (ttsReady) {
                    tts.speak(phrases[mood], TextToSpeech.QUEUE_FLUSH, null);
                }
            }
        });
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int r = tts.setLanguage(new Locale("fa"));
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                Toast.makeText(this, "موتور صدای فارسی نصب نیست", Toast.LENGTH_LONG).show();
            } else {
                ttsReady = true;
            }
        }
    }

    @Override
    public void onBackPressed() {
        // قفل: Back کاری نمی‌کند
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
