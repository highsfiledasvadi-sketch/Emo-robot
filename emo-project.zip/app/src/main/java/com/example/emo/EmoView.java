package com.example.emo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.view.View;

public class EmoView extends View {

    public static final int NORMAL = 0, HAPPY = 1, SURPRISED = 2, SLEEPY = 3;
    private static final int MOOD_COUNT = 4;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Handler handler = new Handler();

    private int mood = NORMAL;
    private float openness = 1f;

    private final Runnable openEyes = new Runnable() {
        public void run() {
            openness = 1f;
            invalidate();
            scheduleBlink();
        }
    };

    private final Runnable closeEyes = new Runnable() {
        public void run() {
            openness = 0.1f;
            invalidate();
            handler.postDelayed(openEyes, 150);
        }
    };

    public EmoView(Context context) {
        super(context);
        setBackgroundColor(Color.BLACK);
        fill.setColor(Color.rgb(0, 220, 255));
        stroke.setColor(Color.rgb(0, 220, 255));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        scheduleBlink();
    }

    private void scheduleBlink() {
        handler.postDelayed(closeEyes, 2000 + (long) (Math.random() * 3000));
    }

    public int nextMood() {
        mood = (mood + 1) % MOOD_COUNT;
        invalidate();
        return mood;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float eyeW = w * 0.18f;
        float eyeH = h * 0.38f;
        float cy = h * 0.40f;
        float[] cx = { w * 0.30f, w * 0.70f };

        stroke.setStrokeWidth(h * 0.04f);

        for (float x : cx) {
            switch (mood) {
                case HAPPY:
                    rect.set(x - eyeW / 2, cy - eyeH / 4, x + eyeW / 2, cy + eyeH / 4);
                    canvas.drawArc(rect, 180, 180, false, stroke);
                    break;
                case SURPRISED:
                    float r = eyeW * 0.55f;
                    canvas.drawCircle(x, cy, r * openness + 2, fill);
                    break;
                case SLEEPY:
                    rect.set(x - eyeW / 2, cy, x + eyeW / 2, cy + eyeH * 0.25f * openness + 4);
                    canvas.drawRoundRect(rect, 20, 20, fill);
                    break;
                default:
                    float eh = eyeH * openness;
                    rect.set(x - eyeW / 2, cy - eh / 2, x + eyeW / 2, cy + eh / 2);
                    canvas.drawRoundRect(rect, eyeW / 3, eyeW / 3, fill);
            }
        }

        float mx = w / 2, my = h * 0.80f;
        if (mood == HAPPY) {
            rect.set(mx - w * 0.08f, my - h * 0.08f, mx + w * 0.08f, my + h * 0.08f);
            canvas.drawArc(rect, 0, 180, false, stroke);
        } else if (mood == SURPRISED) {
            canvas.drawCircle(mx, my, h * 0.05f, stroke);
        } else {
            canvas.drawLine(mx - w * 0.05f, my, mx + w * 0.05f, my, stroke);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null);
        super.onDetachedFromWindow();
    }
}
